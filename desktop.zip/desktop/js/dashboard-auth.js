/* /js/dashboard-auth.js
   Proteção e sessão dos dashboards (aluno, instrutor, admin)
   - Verifica autenticação
   - Aplica guarda por perfil (role)
   - Preenche nome/role dinamicamente
   - Centraliza logout
*/
(() => {
  'use strict';

  // --- Configurações ---
  const DEFAULT_LOGIN_BY_ROLE = {
    aluno: '/pages/login-aluno.html',
    instrutor: '/pages/login-instrutor.html',
    admin: '/pages/login-admin.html',
  };
  const FALLBACK_LOGIN = '/pages/login-aluno.html';

  // Deduz página-alvo pelo caminho atual, para um redirecionamento mais coerente
  function inferRoleFromPath() {
    const p = location.pathname.toLowerCase();
    if (p.includes('admin')) return 'admin';
    if (p.includes('instrutor')) return 'instrutor';
    if (p.includes('prof') || p.includes('teacher')) return 'instrutor';
    return 'aluno';
  }

  // Usa AuthManager se existir; senão, lê do localStorage
  function readUser() {
    if (window.authManager && typeof window.authManager.getUser === 'function') {
      try { return window.authManager.getUser() || null; } catch { /* noop */ }
    }
    try {
      const raw = localStorage.getItem('user_data');
      return raw ? JSON.parse(raw) : null;
    } catch {
      localStorage.removeItem('user_data');
      return null;
    }
  }

  function hasToken() {
    if (window.authManager && typeof window.authManager.isAuthenticated === 'function') {
      try { return !!window.authManager.isAuthenticated(); } catch { /* noop */ }
    }
    return !!localStorage.getItem('auth_token');
  }

  // Redireciona para a página de login adequada
  function goToLogin(preferredRole) {
    const role = preferredRole || inferRoleFromPath();
    const target = DEFAULT_LOGIN_BY_ROLE[role] || FALLBACK_LOGIN;
    window.location.assign(target);
  }

  // Guarda de rota (opcionalmente restrita por roles)
  function guard({ allowRoles = null, redirectTo = null } = {}) {
    const authed = hasToken();
    const user = readUser();

    if (!authed || !user) {
      goToLogin(allowRoles?.[0] || inferRoleFromPath());
      return false;
    }

    const role = String(user.role || '').toLowerCase() || 'aluno';
    if (Array.isArray(allowRoles) && allowRoles.length && !allowRoles.includes(role)) {
      // Logado, mas sem permissão para este dashboard → volta ao login do perfil do usuário
      const target = DEFAULT_LOGIN_BY_ROLE[role] || redirectTo || FALLBACK_LOGIN;
      window.location.assign(target);
      return false;
    }
    return true;
  }

  // Preenche nome/role nos elementos-chave
  function renderUserInfo() {
    const user = readUser();
    if (!user) return;

    // Nome
    document.querySelectorAll('.user-name, .login-btn').forEach(el => {
      if (el && !el.hasAttribute('data-static')) {
        el.textContent = user.name || user.email || 'Usuário';
      }
    });

    // Papel
    document.querySelectorAll('.user-role').forEach(el => {
      if (el && !el.hasAttribute('data-static')) {
        const role = String(user.role || '').toLowerCase();
        let label = 'Usuário';
        if (role === 'aluno') label = 'Aluna(o)';
        if (role === 'instrutor') label = 'Instrutor(a)';
        if (role === 'admin') label = 'Administrador(a)';
        el.textContent = label;
      }
    });
  }

  // Logout centralizado
  function logout({ redirect = true } = {}) {
    try {
      // Se houver AuthManager, peça para ele limpar
      if (window.authManager && typeof window.authManager.logout === 'function') {
        window.authManager.logout(false); // false = não redirecionar, a gente decide abaixo
      }
    } catch { /* noop */ }

    // Limpa chaves padrão usadas no site
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_data');
    localStorage.removeItem('userLoggedIn');
    localStorage.removeItem('userEmail');

    if (redirect) {
      // Redireciona para o login do perfil inferido
      goToLogin();
    }
  }

  // Anexa listeners a botões/links de sair
  function bindLogoutDelegation() {
    document.addEventListener('click', (e) => {
      const a = e.target.closest('a,button');
      if (!a) return;
      if (
        a.matches('[data-action="logout"], .logout, a[href="#logout"], a[href*="sair"], a.dropdown-item[href="#"][onclick*="logout"]')
      ) {
        e.preventDefault();
        logout({ redirect: true });
      }
    });
  }

  // Executa automaticamente nas páginas de dashboard
  document.addEventListener('DOMContentLoaded', () => {
    // Por convenção: se a URL incluir "dashboard-", aplicamos uma guarda.
    const isDashboard = /dashboard-(aluno|instrutor|admin)\.html/i.test(location.pathname);
    if (isDashboard) {
      // Restringe por papel com base no nome do arquivo
      const m = location.pathname.match(/dashboard-(aluno|instrutor|admin)\.html/i);
      const roleFromPath = m ? m[1].toLowerCase() : inferRoleFromPath();
      const ok = guard({ allowRoles: [roleFromPath] });
      if (!ok) return;
    } else {
      // Em outras páginas privadas que, por ventura, usem este script:
      // apenas verifique login básico
      if (!guard()) return;
    }

    renderUserInfo();
    bindLogoutDelegation();
  });

  // Exponha utilitários (útil para depuração/outras partes do site)
  window.dashboardAuth = {
    guard,
    renderUserInfo,
    logout,
    readUser,
    hasToken
  };
})();
