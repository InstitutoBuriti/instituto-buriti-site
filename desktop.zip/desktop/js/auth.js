/**
 * /js/auth.js — SUBSTITUIÇÃO TOTAL
 * Sistema de Autenticação — Instituto Buriti
 * - Guarda de rotas, login/logout programático e verificação de sessão
 * - Compatível com dois modos:
 *      1) DEMO (sem backend) — credenciais fake
 *      2) SUPABASE (produção) — REST Auth v1
 *
 * Observações:
 * - O fluxo de login na página é tratado por /js/login.js.
 *   Este arquivo foca em: estado de sessão, logout, authGuard e utilidades.
 * - Ative o Supabase definindo USE_SUPABASE=true **ou**
 *   expondo window.SUPABASE_URL e window.SUPABASE_ANON_KEY (auto-detect).
 */

/* ==============================
   Configuração
   ============================== */
let USE_SUPABASE = false;           // mude para true em produção
const DEBUG = false;                // mude para true para ver logs

// Auto-detect: se variáveis globais do Supabase estiverem disponíveis, ativa Supabase
try {
  if (window.SUPABASE_URL && window.SUPABASE_ANON_KEY) {
    USE_SUPABASE = true;
  }
} catch { /* noop */ }

// Se quiser forçar via constantes, defina aqui (opcional)
const SUPABASE_URL     = window.SUPABASE_URL     || "https://ngvljtxkinvygynwcckp.supabase.co";
const SUPABASE_ANON_KEY= window.SUPABASE_ANON_KEY|| "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5ndmxqdHhraW52eWd5bndjY2twIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIzMzIxNzksImV4cCI6MjA2NzkwODE3OX0.vwJgc2E_erC3giIofKiVY5ipYM2uRP8m9Yxy0fqE2yY";

// Credenciais DEMO (modo sem backend)
const VALID_CREDENTIALS = {
  "ana.silva@email.com": "123456"
};

/* ==============================
   Utils de log
   ============================== */
function dbg(...a){ if (DEBUG) console.log("[AUTH]", ...a); }
function warn(...a){ if (DEBUG) console.warn("[AUTH]", ...a); }
function err(...a){ if (DEBUG) console.error("[AUTH]", ...a); }

/* ==============================
   Helpers
   ============================== */
const normEmail = (s) => String(s||"").trim().toLowerCase();
const now = () => Date.now();

function storageGetJSON(key, fallback=null){
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
  catch { return fallback; }
}
function storageSetJSON(key, obj){
  try { localStorage.setItem(key, JSON.stringify(obj)); } catch {}
}

/* ==============================
   AuthManager
   ============================== */
class AuthManager {
  constructor() {
    dbg("Inicializando AuthManager…");

    // Estado
    this.session = storageGetJSON("auth_session", null);
    // { access_token, refresh_token, expires_at(ms), user:{id,email,name,role?} }

    // Sync entre abas
    window.addEventListener("storage", (ev) => {
      if (ev.key === "auth_session") {
        this.session = storageGetJSON("auth_session", null);
        dbg("Sessão sincronizada entre abas:", !!this.session);
      }
    });

    // Verificação inicial
    this.verifySession();
  }

  /* --------- Persitência --------- */
  saveSession(sess){
    this.session = sess ? { ...sess } : null;
    if (sess) storageSetJSON("auth_session", this.session);
    else localStorage.removeItem("auth_session");
  }
  clearSession(){
    this.saveSession(null);
  }

  /* --------- Estado --------- */
  isAuthenticated(){
    if (!this.session || !this.session.access_token) return false;
    if (typeof this.session.expires_at === "number" && now() >= this.session.expires_at) {
      dbg("Token expirado.");
      return false;
    }
    return true;
  }
  getUser(){ return this.session?.user || null; }

  /* --------- Guarda de rota --------- */
  authGuard({ redirect = this.getDefaultLoginPath() } = {}){
    if (!this.isAuthenticated()){
      window.location.href = redirect;
      return false;
    }
    return true;
  }

  getDefaultLoginPath(){
    // login padrão para público geral (aluno)
    return "/pages/login-aluno.html";
  }

  /* --------- Verificação inicial --------- */
  verifySession(){
    if (!this.session) { dbg("Sem sessão."); return false; }
    if (!this.isAuthenticated()){
      warn("Sessão inválida/expirada — limpando.");
      this.clearSession();
      return false;
    }
    dbg("Sessão válida, expira em:", new Date(this.session.expires_at||0).toISOString());
    return true;
  }

  /* --------- Login programático (opcional) ---------
     OBS: As páginas de login usarão /js/login.js.
     Este método existe caso algum fluxo precise autenticar por aqui. */
  async login(email, password){
    const e = normEmail(email || "");
    const p = String(password || "");

    if (!e || !p) return { success:false, error:"Credenciais ausentes." };

    try {
      if (USE_SUPABASE){
        // Supabase: password grant
        const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "apikey": SUPABASE_ANON_KEY,
            "Authorization": `Bearer ${SUPABASE_ANON_KEY}`
          },
          body: JSON.stringify({ email: e, password: p })
        });

        const data = await res.json().catch(()=> ({}));
        if (!res.ok){
          const msg = data?.error_description || data?.msg || "Falha no login.";
          return { success:false, error: msg };
        }

        const access_token  = data.access_token;
        const refresh_token = data.refresh_token;
        const expires_in    = Number(data.expires_in || 3600); // segundos
        const expires_at    = now() + expires_in*1000;

        // Opcional: buscar usuário
        let user = { email: e };
        try {
          const uRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
            method: "GET",
            headers: {
              "apikey": SUPABASE_ANON_KEY,
              "Authorization": `Bearer ${access_token}`
            }
          });
          if (uRes.ok){
            const u = await uRes.json();
            user = {
              id: u?.id,
              email: u?.email || e,
              name: u?.user_metadata?.name || u?.email || "Usuário"
            };
          }
        } catch { /* noop */ }

        this.saveSession({ access_token, refresh_token, expires_at, user });
        dbg("Login OK via Supabase para:", user.email);
        return { success:true, user };
      }

      // DEMO
      if (VALID_CREDENTIALS[e] === p){
        const expires_at = now() + 3600*1000;
        const user = { id: 1, email: e, name: "Ana Silva", role: "aluno" };
        this.saveSession({ access_token: "demo_"+Date.now(), refresh_token: null, expires_at, user });
        dbg("Login DEMO OK:", user.email);
        return { success:true, user };
      }
      return { success:false, error:"E-mail ou senha incorretos." };

    } catch (ex){
      err("Erro no login:", ex);
      return { success:false, error:"Erro de conexão." };
    }
  }

  /* --------- Logout --------- */
  async logout({ redirect = this.getDefaultLoginPath() } = {}){
    try {
      if (USE_SUPABASE && this.session?.access_token){
        // Tenta invalidar a sessão no Supabase (não é obrigatório para limpar local)
        try {
          await fetch(`${SUPABASE_URL}/auth/v1/logout`, {
            method: "POST",
            headers: {
              "apikey": SUPABASE_ANON_KEY,
              "Authorization": `Bearer ${this.session.access_token}`
            }
          });
        } catch { /* noop */ }
      }
    } finally {
      this.clearSession();
      window.location.href = redirect;
    }
  }
}

/* ==============================
   Instância global
   ============================== */
const authManager = new AuthManager();
window.authManager = authManager;
dbg("AuthManager pronto — modo:", USE_SUPABASE ? "SUPABASE" : "DEMO");
