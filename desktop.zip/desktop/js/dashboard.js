/* /js/dashboard.js
 * Núcleo de UI para Dashboards (Aluno, Instrutor, Admin)
 * - SPA leve por seções (data-section)
 * - Integra com authManager se disponível
 * - Notificações (toast)
 * - Hooks por perfil: PageHooks.aluno / instrutor / admin
 */

(() => {
  const DASHBOARD = {
    // === Bootstrap ===
    init() {
      // 1) Hidratação de usuário (se authManager estiver carregado)
      this.user = (window.authManager && window.authManager.getUser && window.authManager.getUser()) || null;
      this.hydrateUserUI();

      // 2) Navegação de seções
      this.cacheDom();
      this.bindSidebarToggle();
      this.bindDropdown();
      this.bindSectionNav();

      // 3) Restaurar seção pelo hash (ou manter 'overview')
      this.restoreSectionFromHash();

      // 4) Hooks por perfil (executa o que existir)
      this.runProfileHooks();

      // 5) Segurança: se não houver .main-content, não faz nada
      if (!this.$main) return;

      // 6) Qualquer inicialização adicional global do dashboard
      // (placeholder)
    },

    // === Cache de elementos ===
    cacheDom() {
      this.$sidebar = document.getElementById('sidebar');
      this.$sidebarToggle = document.getElementById('sidebarToggle');
      this.$dropdownBtn = document.querySelector('.login-dropdown .login-btn');
      this.$dropdownMenu = document.querySelector('.login-dropdown .dropdown-menu');
      this.$navLinks = Array.from(document.querySelectorAll('.sidebar-nav .nav-link[data-section]'));
      this.$sections = Array.from(document.querySelectorAll('.dashboard-section'));
      this.$main = document.querySelector('.main-content');
    },

    // === Hidratar cabeçalho/Sidebar com dados do usuário ===
    hydrateUserUI() {
      if (!this.user) return;
      const { name, email, role } = this.user;

      const displayName = name || email || 'Minha conta';
      const displayRole = role ? (String(role)[0].toUpperCase() + String(role).slice(1)) : null;

      const nameTargets = document.querySelectorAll('[data-user-name]');
      const roleTargets = document.querySelectorAll('[data-user-role]');
      const btn = document.querySelector('.login-dropdown .login-btn');

      nameTargets.forEach(el => (el.textContent = displayName));
      roleTargets.forEach(el => (el.textContent = displayRole || el.textContent || ''));
      if (btn) btn.textContent = displayName;
    },

    // === Toggle da sidebar ===
    bindSidebarToggle() {
      if (!this.$sidebarToggle) return;
      this.$sidebarToggle.addEventListener('click', () => {
        this.$sidebar?.classList.toggle('collapsed');
      });
    },

    // === Dropdown de conta ===
    bindDropdown() {
      if (!this.$dropdownBtn || !this.$dropdownMenu) return;

      const toggle = (open) => {
        this.$dropdownMenu.style.display = open ? 'block' : 'none';
        this.$dropdownBtn.setAttribute('aria-expanded', String(open));
      };

      let isOpen = false;
      this.$dropdownBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        isOpen = !isOpen;
        toggle(isOpen);
      });

      document.addEventListener('click', () => {
        if (isOpen) {
          isOpen = false;
          toggle(false);
        }
      });

      // Escape fecha
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && isOpen) {
          isOpen = false;
          toggle(false);
        }
      });
    },

    // === Navegação entre seções (SPA leve) ===
    bindSectionNav() {
      if (!this.$navLinks.length || !this.$sections.length) return;

      this.$navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
          // Links externos (sem data-section) são ignorados
          if (!link.dataset.section) return;

          e.preventDefault();
          const target = link.dataset.section;
          this.activateSection(target);

          // manter no hash para reload/compartilhar URL
          history.replaceState(null, '', `#${encodeURIComponent(target)}`);

          // marcação ativa no menu
          this.$navLinks.forEach(a => a.classList.toggle('active', a === link));

          // acessibilidade básica
          link.setAttribute('aria-current', 'page');
          this.$navLinks.filter(a => a !== link).forEach(a => a.removeAttribute('aria-current'));

          // sobe um pouco a página
          window.scrollTo({ top: 0, behavior: 'smooth' });
        });
      });
    },

    activateSection(sectionId) {
      this.$sections.forEach(sec => {
        const isActive = sec.id === sectionId;
        sec.classList.toggle('active', isActive);
        sec.setAttribute('aria-hidden', String(!isActive));
      });
    },

    restoreSectionFromHash() {
      const hash = decodeURIComponent(location.hash.replace('#', '') || '');
      const exists = this.$sections.some(s => s.id === hash);
      const initial = exists ? hash : 'overview';
      this.activateSection(initial);

      // marcar nav ativa
      this.$navLinks.forEach(a => {
        const on = a.dataset.section === initial;
        a.classList.toggle('active', on);
        if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
      });
    },

    // === Hooks por perfil ===
    runProfileHooks() {
      const role = (this.user && String(this.user.role || '').toLowerCase()) || null;

      // Detecta pelo arquivo atual quando não houver role
      const path = (location.pathname || '').toLowerCase();
      const fallback =
        path.includes('dashboard-admin') ? 'admin' :
        path.includes('dashboard-instrutor') ? 'instrutor' :
        'aluno';

      const detected = role || fallback;

      const hooks = (window.PageHooks && window.PageHooks[detected]) || null;
      if (typeof hooks === 'function') {
        try {
          hooks({ user: this.user, notify: this.notify, http: HTTP });
        } catch (e) {
          console.error('[dashboard] erro ao executar hooks do perfil:', e);
          this.notify('Erro ao carregar dados do painel.', 'error');
        }
      }
    },

    // === Notificações (toast) ===
    notify(message, type = 'info', timeout = 4000) {
      const colors = {
        success: '#28a745',
        error:   '#dc3545',
        warning: '#ffc107',
        info:    '#17a2b8'
      };
      const el = document.createElement('div');
      el.className = `ib-toast ${type}`;
      el.style.cssText = `
        position: fixed; top: 20px; right: 20px; z-index: 9999;
        background: ${colors[type] || colors.info}; color: #fff;
        padding: 12px 16px; border-radius: 8px; box-shadow: 0 8px 24px rgba(0,0,0,.15);
        font: 500 14px/1.3 Inter, system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
        opacity: 0; transform: translateY(-8px); transition: all .25s ease;
        max-width: 360px;
      `;
      el.innerHTML = `<div>${message}</div>`;
      document.body.appendChild(el);
      requestAnimationFrame(() => {
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
      });
      setTimeout(() => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(-8px)';
        setTimeout(() => el.remove(), 250);
      }, timeout);
    }
  };

  // === HTTP helper com Bearer automático (quando houver token) ===
  const HTTP = {
    async get(url, opts = {}) { return HTTP._fetch('GET', url, null, opts); },
    async post(url, body, opts = {}) { return HTTP._fetch('POST', url, body, opts); },
    async put(url, body, opts = {}) { return HTTP._fetch('PUT', url, body, opts); },
    async del(url, opts = {}) { return HTTP._fetch('DELETE', url, null, opts); },

    async _fetch(method, url, body, opts) {
      const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
      // injeta Bearer se existir
      try {
        const token = (window.authManager && localStorage.getItem('auth_token')) || null;
        if (token && url.startsWith('/api')) headers['Authorization'] = `Bearer ${token}`;
      } catch { /* ignore */ }

      const res = await fetch(url, { method, headers, ...(body ? { body: JSON.stringify(body) } : {}), ...opts });
      const contentType = res.headers.get('content-type') || '';
      const isJSON = contentType.includes('application/json');
      const data = isJSON ? await res.json() : await res.text();

      if (!res.ok) {
        const msg = isJSON ? (data.message || JSON.stringify(data)) : String(data);
        throw new Error(msg || `HTTP ${res.status}`);
      }
      return data;
    }
  };

  // === Hooks de exemplo (opcional): remova se quiser começar do zero ===
  // Você pode sobrescrever PageHooks.* em /pages/* com <script> depois de carregar dashboard.js
  window.PageHooks = window.PageHooks || {
    aluno: async ({ user, notify /*, http*/ }) => {
      // Exemplo: notify('Bem-vindo(a) ao seu painel, ' + (user?.name || 'aluno(a)') + '!', 'success');
      // Carregar cursos do aluno: const cursos = await http.get('/api/courses/mine');
    },
    instrutor: async ({ user, notify /*, http*/ }) => {
      // Exemplo: notify('Olá, professor(a)!', 'info');
    },
    admin: async ({ user, notify /*, http*/ }) => {
      // Exemplo: notify('Painel administrativo carregado.', 'info');
    }
  };

  // Boot
  document.addEventListener('DOMContentLoaded', () => DASHBOARD.init());

  // Expo
  window.IBDashboard = { notify: DASHBOARD.notify, http: HTTP };
})();